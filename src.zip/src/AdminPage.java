import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class AdminPage extends JFrame{

private JPanel mainPanel;
private JPanel vaccinePanel;
private JPanel slotPanel;
private JPanel statusPanel;
private JPanel availablePanel;
private JPanel vaccineUpdatePanel;
private JPanel slotUpdatePanel;
private JPanel containerPaneln;
//private JPanel vaccineDeletePanel;
private JPanel slotDeletePanel;
private JPanel userDeletePanel;
private JPanel viewSlotPanel;
private JPanel containerPanel;
private JPanel tablePanel;
private JRadioButton firstDoseRadioButtonSt, secondDoseRadioButtonSt, boosterDoseRadioButtonSt;
private JTextField userIdTextFieldSt, vaccineIdTextFieldSt;
private JPanel panel;

private JLabel vaccineLabel;
private JTextField vaccineField;
private JButton countButton;
private JLabel countLabel;

private JTable table;
private DefaultTableModel model;

private Connection conn;
private Connection connection;

public AdminPage(){

setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setLayout(null);

mainPanel = new JPanel();
mainPanel.setBounds(0, 0, 400, 300);
mainPanel.setLayout(null);
add(mainPanel);

JMenuBar menuBar = new JMenuBar();
setJMenuBar(menuBar);

JMenu insertMenu = new JMenu("Insert");

JMenuItem insertVaccineItem = new JMenuItem("Insert Vaccine");
JMenuItem insertSlotItem = new JMenuItem("Insert Slot");
JMenuItem insertStatusItem = new JMenuItem("Insert Status");
JMenuItem insertAvailableItem = new JMenuItem("Insert Available");

insertMenu.add(insertVaccineItem);
insertMenu.add(insertSlotItem);
insertMenu.add(insertStatusItem);
insertMenu.add(insertAvailableItem);

menuBar.add(insertMenu);

JMenu updateMenu = new JMenu("Update");


JMenuItem updateVaccineItem = new JMenuItem("Update Vaccine");
JMenuItem updateSlotItem = new JMenuItem("Update Slot");


updateMenu.add(updateVaccineItem);
updateMenu.add(updateSlotItem);

menuBar.add(updateMenu);

JMenu deleteMenu = new JMenu("Delete");


JMenuItem deleteSlotItem = new JMenuItem("Delete Slot");

deleteMenu.add(deleteSlotItem);

menuBar.add(deleteMenu);

JMenu viewSlotMenu = new JMenu("View");

JMenuItem viewSlotItem = new JMenuItem("View Slot");
viewSlotMenu.add(viewSlotItem);
JMenuItem viewCountItem = new JMenuItem("View count");
viewSlotMenu.add(viewCountItem);
JMenuItem viewVaccineItem = new JMenuItem("View Vaccine");
viewSlotMenu.add(viewVaccineItem);


menuBar.add(viewSlotMenu);

JMenu HomeMenu = new JMenu("SignOut");

JMenuItem HomeItem = new JMenuItem("Signout");
HomeMenu.add(HomeItem);
menuBar.add(HomeMenu);


availablePanel = new JPanel();
availablePanel.setBounds(0, 0, 400, 300);
availablePanel.setLayout(null);
availablePanel.setVisible(false);
mainPanel.add(availablePanel);

statusPanel = new JPanel();
statusPanel.setBounds(0, 0, 400, 300);
statusPanel.setLayout(null);
statusPanel.setVisible(false);
mainPanel.add(statusPanel);

slotPanel = new JPanel();
slotPanel.setBounds(0, 0, 400, 300);
slotPanel.setLayout(null);
slotPanel.setVisible(false);
mainPanel.add(slotPanel);

vaccinePanel = new JPanel();
vaccinePanel.setBounds(0, 0, 400, 300);
vaccinePanel.setLayout(null);
vaccinePanel.setVisible(false);
mainPanel.add(vaccinePanel);

vaccineUpdatePanel= new JPanel();
vaccineUpdatePanel.setBounds(0, 0, 400, 300);
vaccineUpdatePanel.setLayout(null);
vaccineUpdatePanel.setVisible(false);
mainPanel.add(vaccineUpdatePanel);

slotUpdatePanel = new JPanel();
slotUpdatePanel.setBounds(0, 0, 400, 300);
slotUpdatePanel.setLayout(null);
slotUpdatePanel.setVisible(false);
mainPanel.add(slotUpdatePanel);



slotDeletePanel = new JPanel();
slotDeletePanel.setBounds(0, 0, 400, 300);
slotDeletePanel.setLayout(null);
slotDeletePanel.setVisible(false);
mainPanel.add(slotDeletePanel);



viewSlotPanel = new JPanel();
viewSlotPanel.setBounds(0, 0, 400, 300);
viewSlotPanel.setLayout(null);
viewSlotPanel.setVisible(false);
mainPanel.add(viewSlotPanel);

containerPanel = new JPanel();
containerPanel.setBounds(0, 0, 400, 300);
containerPanel.setLayout(new BorderLayout());
containerPanel.setVisible(false);
mainPanel.add(containerPanel);

containerPaneln = new JPanel();
containerPaneln.setBounds(0, 0, 400, 300);
containerPaneln.setLayout(new BorderLayout());
containerPaneln.setVisible(false);
mainPanel.add(containerPaneln);



JLabel lblVaccineIdava = new JLabel("Vaccine ID:");
lblVaccineIdava.setBounds(50, 50, 100, 25);
availablePanel.add(lblVaccineIdava);

JTextField txtVaccineIdava = new JTextField();
txtVaccineIdava.setBounds(150, 50, 200, 25);
availablePanel.add(txtVaccineIdava);

JLabel lblSlotIdAva = new JLabel("Slot Id:");
lblSlotIdAva.setBounds(50, 100, 100, 25);
availablePanel.add(lblSlotIdAva);

JTextField txtSlotIdAva = new JTextField();
txtSlotIdAva.setBounds(150, 100, 200, 25);
availablePanel.add(txtSlotIdAva);

JLabel lblCapacity = new JLabel("Capacity:");
lblCapacity.setBounds(50, 150, 100, 25);
availablePanel.add(lblCapacity);

JTextField txtCapacity = new JTextField();
txtCapacity.setBounds(150, 150, 200, 25);
availablePanel.add(txtCapacity);

JButton btnSubmitAvailable = new JButton("Submit");
btnSubmitAvailable.setBounds(150, 200, 100, 30);
btnSubmitAvailable.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle user details submission
        String VaccineIdava = txtVaccineIdava.getText();
        String SlotIdAva = txtSlotIdAva.getText();
        String CapacityAva = txtCapacity.getText();

        // Insert user details into the database
        insertAvailableDetails(VaccineIdava,SlotIdAva,CapacityAva);

        // Reset the text fields
        txtVaccineIdava.setText("");
        txtSlotIdAva.setText("");
        txtCapacity.setText("");
    }
});
availablePanel.add(btnSubmitAvailable);

/*JLabel lblUserIdSt = new JLabel("User ID:");
lblUserIdSt.setBounds(50, 50, 100, 25);
statusPanel.add(lblUserIdSt);

JTextField txtUserIdSt = new JTextField();
txtUserIdSt.setBounds(150, 50, 200, 25);
statusPanel.add(txtUserIdSt);

JLabel lblVaccineIdSt = new JLabel("Vaccine Id:");
lblVaccineIdSt.setBounds(50, 100, 100, 25);
statusPanel.add(lblVaccineIdSt);

JTextField txtVaccineIdSt = new JTextField();
txtVaccineIdSt .setBounds(150, 100, 200, 25);
statusPanel.add(txtVaccineIdSt);

JLabel lblCountSt = new JLabel("Count:");
lblCountSt.setBounds(50, 150, 100, 25);
statusPanel.add(lblCountSt);

JTextField txtCountSt = new JTextField();
txtCountSt.setBounds(150, 150, 200, 25);
statusPanel.add(txtCountSt);

JButton btnSubmitStatus = new JButton("Submit");
btnSubmitStatus.setBounds(150, 200, 100, 30);
btnSubmitStatus.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
    // Handle user details submission
    String userIdSt = txtUserIdSt.getText();
    String vaccineIdSt = txtVaccineIdSt.getText();
    String countSt = txtCountSt.getText();

    // Insert user details into the database
    insertStatusDetails(userIdSt, vaccineIdSt, countSt);

    // Reset the text fields
    txtUserIdSt.setText("");
    txtVaccineIdSt.setText("");
    txtCountSt.setText("");
}
});
statusPanel.add(btnSubmitStatus);*/



panel = new JPanel(null);
panel.setBounds(0, 0, 400, 300);
panel.setLayout(null);

vaccineLabel = new JLabel("Vaccine ID:");
vaccineLabel.setBounds(10, 10, 80, 25);
panel.add(vaccineLabel);

vaccineField = new JTextField();
vaccineField.setBounds(100, 10, 100, 25);
panel.add(vaccineField);

countButton = new JButton("Count");
countButton.setBounds(210, 10, 80, 25);
countButton.addActionListener(e -> countUsers());
panel.add(countButton);

countLabel = new JLabel("");
countLabel.setBounds(10, 40, 280, 25);
panel.add(countLabel);

mainPanel.add(panel);

JLabel userIdLabelSt = new JLabel("User ID:");
        userIdLabelSt.setBounds(20, 20, 80, 25);
        statusPanel.add(userIdLabelSt);

        userIdTextFieldSt = new JTextField();
        userIdTextFieldSt.setBounds(110, 20, 150, 25);
        statusPanel.add(userIdTextFieldSt);

        // Create and position the Vaccine ID label and text field
        JLabel vaccineIdLabelSt = new JLabel("Vaccine ID:");
        vaccineIdLabelSt.setBounds(20, 60, 80, 25);
        statusPanel.add(vaccineIdLabelSt);

        vaccineIdTextFieldSt = new JTextField();
        vaccineIdTextFieldSt.setBounds(110, 60, 150, 25);
        statusPanel.add(vaccineIdTextFieldSt);

        // Create and position the Dose label and radio buttons
        JLabel doseLabelSt = new JLabel("Dose:");
        doseLabelSt.setBounds(20, 100, 80, 25);
        statusPanel.add(doseLabelSt);

        firstDoseRadioButtonSt = new JRadioButton("First Dose");
        firstDoseRadioButtonSt.setBounds(110, 100, 100, 25);
        statusPanel.add(firstDoseRadioButtonSt);

        secondDoseRadioButtonSt = new JRadioButton("Second Dose");
        secondDoseRadioButtonSt.setBounds(220, 100, 120, 25);
        statusPanel.add(secondDoseRadioButtonSt);

        boosterDoseRadioButtonSt = new JRadioButton("Booster Dose");
        boosterDoseRadioButtonSt.setBounds(110, 130, 120, 25);
        statusPanel.add(boosterDoseRadioButtonSt);

        // Group the radio buttons together
        ButtonGroup doseButtonGroup = new ButtonGroup();
        doseButtonGroup.add(firstDoseRadioButtonSt);
        doseButtonGroup.add(secondDoseRadioButtonSt);
        doseButtonGroup.add(boosterDoseRadioButtonSt);

        JButton submitButtonstatus = new JButton("Submit");
        submitButtonstatus.setBounds(150, 170, 100, 30);
        statusPanel.add(submitButtonstatus);

        // Add action listener to the submit button
        submitButtonstatus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get the selected dose
                String dose = "";
                if (firstDoseRadioButtonSt.isSelected()) {
                    dose = "First Dose";
                } else if (secondDoseRadioButtonSt.isSelected()) {
                    dose = "Second Dose";
                } else if (boosterDoseRadioButtonSt.isSelected()) {
                    dose = "Booster Dose";
                }

                // Get the user ID and vaccine ID
                String userId = userIdTextFieldSt.getText();
                String vaccineId = vaccineIdTextFieldSt.getText();

                // Update the user dose status
                updateUserDoseStatus(userId, vaccineId, dose);
            }
        });

        // Add the status panel to the main panel
        mainPanel.add(statusPanel);

        // Add the main panel to the frame







JLabel lblslotID = new JLabel("SlotId:");
lblslotID.setBounds(50, 50, 100, 25);
slotPanel.add(lblslotID);

JTextField txtslotID = new JTextField();
txtslotID.setBounds(150, 50, 200, 25);
slotPanel.add(txtslotID);

JLabel lblslotLocation = new JLabel("slotLocation:");
lblslotLocation.setBounds(50, 100, 100, 25);
slotPanel.add(lblslotLocation);

JTextField txtslotLocation = new JTextField();
txtslotLocation.setBounds(150, 100, 200, 25);
slotPanel.add(txtslotLocation);

JLabel lblslotName = new JLabel("slot Name:");
lblslotName.setBounds(50, 150, 100, 25);
slotPanel.add(lblslotName);

JTextField txtslotName = new JTextField();
txtslotName.setBounds(150, 150, 200, 25);
slotPanel.add(txtslotName);

JButton btnSubmitSlot = new JButton("Submit");
btnSubmitSlot.setBounds(150, 200, 100, 30);

btnSubmitSlot.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle vaccine details submission
        String SlotId = txtslotID.getText();
        String slotLocation = txtslotLocation.getText();
        String slotName = txtslotName.getText();

        // Insert vaccine details into the database
        insertSlotDetails(SlotId, slotLocation, slotName);

        // Reset the text fields
        txtslotID.setText("");
        txtslotLocation.setText("");
        txtslotName.setText("");
    }
});
slotPanel.add(btnSubmitSlot);

JLabel lblVaccineId = new JLabel("Vaccine ID:");
lblVaccineId.setBounds(50, 50, 100, 25);
vaccinePanel.add(lblVaccineId);

JTextField txtVaccineId = new JTextField();
txtVaccineId.setBounds(150, 50, 200, 25);
vaccinePanel.add(txtVaccineId);

JLabel lblVaccineName = new JLabel("Vaccine Name:");
lblVaccineName.setBounds(50, 100, 100, 25);
vaccinePanel.add(lblVaccineName);

JTextField txtVaccineName = new JTextField();
txtVaccineName.setBounds(150, 100, 200, 25);
vaccinePanel.add(txtVaccineName);

/*JLabel lblDoseCount = new JLabel("Dose Count:");
lblDoseCount.setBounds(50, 150, 100, 25);
vaccinePanel.add(lblDoseCount);

JTextField txtDoseCount = new JTextField();
txtDoseCount.setBounds(150, 150, 200, 25);
vaccinePanel.add(txtDoseCount);*/

JButton btnSubmitVaccine = new JButton("Submit");
btnSubmitVaccine.setBounds(150, 200, 100, 30);
btnSubmitVaccine.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle vaccine details submission
        String vaccineId = txtVaccineId.getText();
        String vaccineName = txtVaccineName.getText();
        String doseCount = "3";

        // Insert vaccine details into the database
        insertVaccineDetails(vaccineId, vaccineName, "3");

        // Reset the text fields
        txtVaccineId.setText("");
        txtVaccineName.setText("");

    }
});
vaccinePanel.add(btnSubmitVaccine);





JLabel lblVaccineUpdateId = new JLabel("Vaccine ID:");
        lblVaccineUpdateId.setBounds(50, 50, 100, 25);
        vaccineUpdatePanel.add(lblVaccineUpdateId);

        JTextField txtVaccineUpdateId = new JTextField();
        txtVaccineUpdateId.setBounds(150, 50, 200, 25);
        vaccineUpdatePanel.add(txtVaccineUpdateId);

        JLabel lblVaccineUpdateName = new JLabel("Vaccine Name:");
        lblVaccineUpdateName.setBounds(50, 80, 100, 25);
        vaccineUpdatePanel.add(lblVaccineUpdateName);

        JTextField txtVaccineUpdateName = new JTextField();
        txtVaccineUpdateName.setBounds(150, 80, 200, 25);
        vaccineUpdatePanel.add(txtVaccineUpdateName);

        JLabel lblDoseUpdateCount = new JLabel("Dose Count:");
        lblDoseUpdateCount.setBounds(50, 110, 100, 25);
        vaccineUpdatePanel.add(lblDoseUpdateCount);

        JTextField txtDoseUpdateCount = new JTextField();
        txtDoseUpdateCount.setBounds(150, 110, 200, 25);
        vaccineUpdatePanel.add(txtDoseUpdateCount);

        JButton btnUpdateVaccine = new JButton("Update");
        btnUpdateVaccine.setBounds(150, 160, 100, 30);
        btnUpdateVaccine.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle vaccine update
                String vaccineId = txtVaccineUpdateId.getText();
                String vaccineName = txtVaccineUpdateId.getText();
                int doseCount = Integer.parseInt(txtDoseUpdateCount.getText());

                // Update vaccine in the database
                updateVaccine(vaccineId, vaccineName, doseCount);

                // Reset the text fields
                txtVaccineUpdateId.setText("");
                txtVaccineUpdateId.setText("");
                txtDoseUpdateCount.setText("");
            }
        });
        vaccineUpdatePanel.add(btnUpdateVaccine);
        JLabel lblSlotUpdateId = new JLabel("Slot ID:");
              lblSlotUpdateId.setBounds(50, 50, 100, 25);
              slotUpdatePanel.add(lblSlotUpdateId);

              JTextField txtSlotUpdateId = new JTextField();
              txtSlotUpdateId.setBounds(150, 50, 200, 25);
              slotUpdatePanel.add(txtSlotUpdateId);

              JLabel lblLocationUpdateName = new JLabel("Location Name:");
              lblLocationUpdateName.setBounds(50, 80, 100, 25);
              slotUpdatePanel.add(lblLocationUpdateName);

              JTextField txtLocationUpdateName = new JTextField();
              txtLocationUpdateName.setBounds(150, 80, 200, 25);
              slotUpdatePanel.add(txtLocationUpdateName);

              JLabel lblSlotUpdateName = new JLabel("Slot Name:");
              lblSlotUpdateName.setBounds(50, 110, 100, 25);
              slotUpdatePanel.add(lblSlotUpdateName);

              JTextField txtSlotUpdateName = new JTextField();
              txtSlotUpdateName.setBounds(150, 110, 200, 25);
              slotUpdatePanel.add(txtSlotUpdateName);

              JButton btnUpdateSlot = new JButton("Update");
              btnUpdateSlot.setBounds(150, 160, 100, 30);
             btnUpdateSlot.addActionListener(new ActionListener() {
                  @Override
                  public void actionPerformed(ActionEvent e) {
                      // Handle slot update
                      String slotId = txtSlotUpdateId.getText();
                      String slotLocation = txtLocationUpdateName.getText();
                      String slotName = txtSlotUpdateName.getText();
                      // Show slot update form
                      updateSlot(slotId,slotLocation,slotName);

                      // Reset the text field
                      txtSlotUpdateId.setText("");
      		txtLocationUpdateName.setText("");
      		txtSlotUpdateName.setText("");
                  }
              });
              slotUpdatePanel.add(btnUpdateSlot);




                      JLabel lblDeleteSlotId = new JLabel("Slot ID:");
                              lblDeleteSlotId.setBounds(50, 50, 100, 25);
                              slotDeletePanel.add(lblDeleteSlotId);

                              JTextField txtDeleteSlotId = new JTextField();
                              txtDeleteSlotId.setBounds(150, 50, 200, 25);
                              slotDeletePanel.add(txtDeleteSlotId);

                              JButton btnDeleteSlot = new JButton("Delete");
                              btnDeleteSlot.setBounds(150, 100, 100, 30);
                              btnDeleteSlot.addActionListener(new ActionListener() {
                                  @Override
                                  public void actionPerformed(ActionEvent e) {
                                      // Handle slot deletion
                                      String slotId = txtDeleteSlotId.getText();

                                      // Delete slot from the database
                                      deleteSlot(slotId);

                                      // Reset the text field
                                      txtDeleteSlotId.setText("");
                                  }
                              });
                              slotDeletePanel.add(btnDeleteSlot);





insertAvailableItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        slotPanel.setVisible(false);
        statusPanel.setVisible(false);
        availablePanel.setVisible(true);
        vaccinePanel.setVisible(false);
        vaccineUpdatePanel.setVisible(false);
          slotUpdatePanel.setVisible(false);

          panel.setVisible(false);

          slotDeletePanel.setVisible(false);

          containerPanel.setVisible(false);
            containerPaneln.setVisible(false);


    }
});



viewCountItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        slotPanel.setVisible(false);
        statusPanel.setVisible(false);
        availablePanel.setVisible(false);
        vaccinePanel.setVisible(false);
        vaccineUpdatePanel.setVisible(false);
          slotUpdatePanel.setVisible(false);
          panel.setVisible(true);

          slotDeletePanel.setVisible(false);

          containerPanel.setVisible(false);
            containerPaneln.setVisible(false);



    }
});


insertStatusItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {


          slotPanel.setVisible(false);
          statusPanel.setVisible(true);
          availablePanel.setVisible(false);
            vaccinePanel.setVisible(false);
            vaccineUpdatePanel.setVisible(false);
              slotUpdatePanel.setVisible(false);
              panel.setVisible(false);
              slotDeletePanel.setVisible(false);

              containerPanel.setVisible(false);
                containerPaneln.setVisible(false);




    }
});

insertSlotItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {

        slotPanel.setVisible(true);
          statusPanel.setVisible(false);
          availablePanel.setVisible(false);
            vaccinePanel.setVisible(false);
            vaccineUpdatePanel.setVisible(false);
              slotUpdatePanel.setVisible(false);
              panel.setVisible(false);

              containerPanel.setVisible(false);
                containerPaneln.setVisible(false);



    }
});

insertVaccineItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {

        slotPanel.setVisible(false);
        statusPanel.setVisible(false);
        vaccinePanel.setVisible(true);
        availablePanel.setVisible(false);
        vaccineUpdatePanel.setVisible(false);
          slotUpdatePanel.setVisible(false);
          panel.setVisible(false);

          containerPanel.setVisible(false);
            containerPaneln.setVisible(false);



    }
});

updateVaccineItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      slotPanel.setVisible(false);
      statusPanel.setVisible(false);
      availablePanel.setVisible(false);
        vaccinePanel.setVisible(false);
        vaccineUpdatePanel.setVisible(true);
        slotUpdatePanel.setVisible(false);
        panel.setVisible(false);



        containerPanel.setVisible(false);
          containerPaneln.setVisible(false);





    }
});

updateSlotItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      slotPanel.setVisible(false);
      statusPanel.setVisible(false);
      availablePanel.setVisible(false);
        vaccinePanel.setVisible(false);
        panel.setVisible(false);
        vaccineUpdatePanel.setVisible(false);
        slotUpdatePanel.setVisible(true);
        slotDeletePanel.setVisible(false);

        containerPanel.setVisible(false);
          containerPaneln.setVisible(false);



    }
});


deleteSlotItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      slotPanel.setVisible(false);
      statusPanel.setVisible(false);
      availablePanel.setVisible(false);
      vaccinePanel.setVisible(false);
      vaccineUpdatePanel.setVisible(false);
        slotUpdatePanel.setVisible(false);
        panel.setVisible(false);
        slotDeletePanel.setVisible(true);

        containerPanel.setVisible(false);
          containerPaneln.setVisible(false);

    }
});




HomeItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      setVisible(false);
      new LoginPagen();
    }
});

viewSlotItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      try {
      try{
      Class.forName("oracle.jdbc.driver.OracleDriver");
    }
    catch(Exception q){
      q.printStackTrace();
    }
    connection=DriverManager.getConnection(
      "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");
      Statement statement = connection.createStatement();

            // Execute the query
            String query = "SELECT s.slot_id, v.vaccine_id, v.name,a.capacity FROM slot s JOIN available a ON s.slot_id = a.slot_id JOIN vaccine v ON a.vaccine_id = v.vaccine_id";
            ResultSet resultSet = statement.executeQuery(query);

            // Create a 2D array to store the data
            Object[][] data = new Object[100][4]; // Assuming there are 100 rows in the Slot table

            // Populate the data array with the query results
            int row = 0;
            while (resultSet.next()) {
                int id = resultSet.getInt("slot_id");
                int vid = resultSet.getInt("vaccine_id");
                String name = resultSet.getString("name");
                int capacity = resultSet.getInt("capacity");

                data[row][0] = id;
                data[row][1] = vid;
                data[row][2] = name;
                data[row][3] = capacity;
                row++;
            }

            // Define the column names
            String[] columnNames = {"ID", "Vid", "Name", "Capacity"};

            // Create a JTable with the data and column names
            JTable table = new JTable(data, columnNames);

            // Create a JScrollPane to add scroll functionality to the table
            JScrollPane scrollPane = new JScrollPane(table);

            // Create a view panel to hold additional components
            JPanel viewPanel = new JPanel();
            // Add components to the view panel
            viewPanel.add(new JLabel("View Panel Component"));

            // Create a container panel to hold the table and the view panel
            //JPanel containerPanel = new JPanel(new BorderLayout());
            containerPanel.add(scrollPane, BorderLayout.CENTER);
            containerPanel.add(viewPanel, BorderLayout.SOUTH);
          //  mainPanel.add(containerPanel);
          slotPanel.setVisible(false);
          statusPanel.setVisible(false);
          availablePanel.setVisible(false);
          vaccinePanel.setVisible(false);
          vaccineUpdatePanel.setVisible(false);
            slotUpdatePanel.setVisible(false);
            panel.setVisible(false);


        containerPanel.setVisible(true);
        containerPaneln.setVisible(false);

    }
    catch(Exception q){
      q.printStackTrace();
    }

}});


viewVaccineItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      try {
      try{
      Class.forName("oracle.jdbc.driver.OracleDriver");
    }
    catch(Exception q){
      q.printStackTrace();
    }
    connection=DriverManager.getConnection(
      "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");
      Statement statement = connection.createStatement();

            // Execute the query
            String query = "SELECT vaccine_id, name FROM vaccine";
            ResultSet resultSet = statement.executeQuery(query);

            // Create a 2D array to store the data
            Object[][] data = new Object[100][2]; // Assuming there are 100 rows in the Slot table

            // Populate the data array with the query results
            int row = 0;
            while (resultSet.next()) {

                int vid = resultSet.getInt("vaccine_id");
                String name = resultSet.getString("name");


                data[row][0] = vid;
                data[row][1] = name;

                row++;
            }

            // Define the column names
            String[] columnNames = { "Vid", "Name"};

            // Create a JTable with the data and column names
            JTable table = new JTable(data, columnNames);

            // Create a JScrollPane to add scroll functionality to the table
            JScrollPane scrollPane = new JScrollPane(table);

            // Create a view panel to hold additional components
            JPanel viewPanel = new JPanel();
            // Add components to the view panel
            viewPanel.add(new JLabel("View Panel Component"));

            // Create a container panel to hold the table and the view panel
            //JPanel containerPanel = new JPanel(new BorderLayout());
            containerPaneln.add(scrollPane, BorderLayout.CENTER);
            containerPaneln.add(viewPanel, BorderLayout.SOUTH);
          //  mainPanel.add(containerPanel);
          slotPanel.setVisible(false);
          statusPanel.setVisible(false);
          availablePanel.setVisible(false);
          vaccinePanel.setVisible(false);
          vaccineUpdatePanel.setVisible(false);
            slotUpdatePanel.setVisible(false);
            panel.setVisible(false);
            containerPanel.setVisible(false);


        containerPaneln.setVisible(true);

    }
    catch(Exception q){
      q.printStackTrace();
    }

}});

setSize(400, 300);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setLayout(null);
setVisible(true);
}

private void insertAvailableDetails(String VaccineIdava,String SlotIdAva,String CapacityAva){
  try {
      // Establish database connection
      try{
      Class.forName("oracle.jdbc.driver.OracleDriver");
    }
    catch(Exception q){
      q.printStackTrace();
    }
      conn=DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");

      // Prepare SQL statement
      String query = "INSERT INTO available (vaccine_id, slot_id, capacity) VALUES (?, ?, ?)";
      PreparedStatement preparedStatement = conn.prepareStatement(query);

      // Set parameter values
      preparedStatement.setString(1, VaccineIdava);
      preparedStatement.setString(2, SlotIdAva);
      preparedStatement.setString(3, CapacityAva);

      // Execute the query
      preparedStatement.executeUpdate();

      // Close the statement and connection
      preparedStatement.close();
      conn.close();

      // Display success message
      JOptionPane.showMessageDialog(null, "Available details inserted successfully!");

  } catch (SQLException ex) {
      ex.printStackTrace();
      JOptionPane.showMessageDialog(null, "Error: Failed to insert user details.");
  }

}
private void insertStatusDetails(String userIdSt, String vaccineIdSt, String countSt){
  try {
      // Establish database connection
      try{
      Class.forName("oracle.jdbc.driver.OracleDriver");
    }
    catch(Exception q){
      q.printStackTrace();
    }
      conn=DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");

      // Prepare SQL statement
      String query = "INSERT INTO userdosestatus (user_id, vaccine_id, count) VALUES (?, ?, ?)";
      PreparedStatement preparedStatement = conn.prepareStatement(query);

      // Set parameter values
      preparedStatement.setString(1, userIdSt);
      preparedStatement.setString(2, vaccineIdSt);
      preparedStatement.setString(3, countSt);

      // Execute the query
      preparedStatement.executeUpdate();

      // Close the statement and connection
      preparedStatement.close();
      conn.close();

      // Display success message
      JOptionPane.showMessageDialog(null, "User details inserted successfully!");

  } catch (SQLException ex) {
      ex.printStackTrace();
      JOptionPane.showMessageDialog(null, "Error: Failed to insert user details.");
  }
}

private void insertSlotDetails(String SlotId, String slotLocation, String slotName)
{
  try{
  try{
  Class.forName("oracle.jdbc.driver.OracleDriver");
}
catch(Exception q){
  q.printStackTrace();
}
  conn=DriverManager.getConnection(
    "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");
    String query = "INSERT INTO slot (slot_id, location, name) VALUES (?, ?, ?)";
    PreparedStatement preparedStatement = conn.prepareStatement(query);

    // Set parameter values
    preparedStatement.setString(1, SlotId);
    preparedStatement.setString(2, slotLocation);
    preparedStatement.setString(3, slotName);

    // Execute the query
    preparedStatement.executeUpdate();

    // Close the statement and connection
    preparedStatement.close();
    conn.close();

    // Display success message
    JOptionPane.showMessageDialog(null, "Vaccine details inserted successfully!");
  }
    catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error: Failed to insert vaccine details.");
    }
}

private void insertVaccineDetails(String vaccineId, String vaccineName, String doseCount) {
    try {
        // Establish database connection
        try{
        Class.forName("oracle.jdbc.driver.OracleDriver");
      }
      catch(Exception q){
        q.printStackTrace();
      }
        conn=DriverManager.getConnection(
          "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");

        // Prepare SQL statement
        String query = "INSERT INTO vaccine (vaccine_id, name, dose_count) VALUES (?, ?, ?)";
        PreparedStatement preparedStatement = conn.prepareStatement(query);

        // Set parameter values
        preparedStatement.setString(1, vaccineId);
        preparedStatement.setString(2, vaccineName);
        preparedStatement.setString(3, doseCount);

        // Execute the query
        preparedStatement.executeUpdate();

        // Close the statement and connection
        preparedStatement.close();
        conn.close();

        // Display success message
        JOptionPane.showMessageDialog(null, "Vaccine details inserted successfully!");

    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error: Failed to insert vaccine details.");
    }
}
private void updateVaccine(String vaccineId, String vaccineName, int doseCount) {
    try {
      try{
      Class.forName("oracle.jdbc.driver.OracleDriver");
    }
    catch(Exception q){
      q.printStackTrace();
    }
    conn=DriverManager.getConnection(
      "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");

        // Prepare SQL statement
        String query = "UPDATE vaccine SET name = ?, dose_count = ? WHERE vaccine_id = ?";
        PreparedStatement preparedStatement = conn.prepareStatement(query);

        // Set parameter values
        preparedStatement.setString(1, vaccineName);
        preparedStatement.setInt(2, doseCount);
        preparedStatement.setString(3, vaccineId);

        // Execute the query
        int rowsAffected = preparedStatement.executeUpdate();

        // Close the statement and connection
        preparedStatement.close();
        conn.close();

        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(null, "Vaccine updated successfully!");
        } else {
            JOptionPane.showMessageDialog(null, "Vaccine with the given ID not found.");
        }

    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error: Failed to update vaccine.");
    }
}
private void updateSlot(String slotId,String slotLocation,String slotName) {
  try {
    try{
    Class.forName("oracle.jdbc.driver.OracleDriver");
  }
  catch(Exception q){
    q.printStackTrace();
  }
  conn=DriverManager.getConnection(
    "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");

      // Prepare SQL statement
      String query = "UPDATE slot SET location = ?, name = ? WHERE slot_id = ?";
      PreparedStatement preparedStatement = conn.prepareStatement(query);

      // Set parameter values
      preparedStatement.setString(1,slotLocation );
      preparedStatement.setString(2, slotName);
      preparedStatement.setString(3, slotId);

      // Execute the query
      int rowsAffected = preparedStatement.executeUpdate();

      // Close the statement and connection
      preparedStatement.close();
      conn.close();

      if (rowsAffected > 0) {
          JOptionPane.showMessageDialog(null, "Vaccine updated successfully!");
      } else {
          JOptionPane.showMessageDialog(null, "Vaccine with the given ID not found.");
      }

  } catch (SQLException ex) {
      ex.printStackTrace();
      JOptionPane.showMessageDialog(null, "Error: Failed to update vaccine.");
  }
}


private void deleteSlot(String slotId) {
    try {
        // Establish database connection
        try{
        Class.forName("oracle.jdbc.driver.OracleDriver");
      }
      catch(Exception q){
        q.printStackTrace();
      }
        conn=DriverManager.getConnection(
          "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");

        // Prepare SQL statement
        String query = "DELETE FROM slot WHERE slot_id = ?";
        PreparedStatement preparedStatement = conn.prepareStatement(query);

        // Set parameter value
        preparedStatement.setString(1, slotId);

        // Execute the query
        int rowsAffected = preparedStatement.executeUpdate();

        // Close the statement and connection
        preparedStatement.close();
        conn.close();

        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(null, "Slot deleted successfully!");
        } else {
            JOptionPane.showMessageDialog(null, "Slot with the given ID not found.");
        }

    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error: Failed to delete slot.");
    }
}
private void updateUserDoseStatus(String userId, String vaccineId, String dose) {
    // JDBC connection variables
    try {
    try{
    Class.forName("oracle.jdbc.driver.OracleDriver");
  }
  catch(Exception q){
    q.printStackTrace();
  }
  connection=DriverManager.getConnection(
    "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");
    PreparedStatement statement = null;

        // Establish the database connection

        // Check if the user ID already exists
        String selectQuery = "SELECT * FROM userdosestatus WHERE user_id = ?";
        statement = connection.prepareStatement(selectQuery);
        statement.setString(1, userId);
        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            // User ID exists, update the columns
            String updateQuery = "UPDATE userdosestatus SET ";
            switch (dose) {
                case "First Dose":
                    updateQuery += "firstdose = 1";
                    break;
                case "Second Dose":
                    updateQuery += "seconddose = 1";
                    break;
                case "Booster Dose":
                    updateQuery += "boosterdose = 1";
                    break;
            }
            updateQuery += " WHERE user_id = ?";
            statement = connection.prepareStatement(updateQuery);
            statement.setString(1, userId);
            int rowsAffected = statement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("User dose status updated successfully!");
            } else {
                System.out.println("Failed to update user dose status.");
            }
        } else {
            // User ID does not exist, insert a new row
            String insertQuery = "INSERT INTO userdosestatus (user_id, vaccine_id, ";
            switch (dose) {
                case "First Dose":
                    insertQuery += "firstdose) VALUES (?, ?, 1)";
                    break;
                case "Second Dose":
                    insertQuery += "seconddose) VALUES (?, ?, 1)";
                    break;
                case "Booster Dose":
                    insertQuery += "boosterdose) VALUES (?, ?, 1)";
                    break;
            }
            statement = connection.prepareStatement(insertQuery);
            statement.setString(1, userId);
            statement.setString(2, vaccineId);
            int rowsAffected = statement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("User dose status inserted successfully!");
            } else {
                System.out.println("Failed to insert user dose status.");
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

private void countUsers() {
    Connection connection = null;
    Statement statement = null;
    ResultSet resultSet = null;

    try {
      try{
      Class.forName("oracle.jdbc.driver.OracleDriver");
    }
    catch(Exception q){
      q.printStackTrace();
    }
    connection=DriverManager.getConnection(
      "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");

        int vaccineId = Integer.parseInt(vaccineField.getText());

        statement = connection.createStatement();
        resultSet = statement.executeQuery("SELECT SUM(CASE WHEN firstdose = 1 THEN 1 " +
                "WHEN firstdose = 1 AND seconddose = 1 THEN 2 " +
                "WHEN firstdose = 1 AND seconddose = 1 AND boosterdose = 1 THEN 3 ELSE 0 END) " +
                "AS total_count FROM userdosestatus WHERE vaccine_id = " + vaccineId + " GROUP BY vaccine_id");

        if (resultSet.next()) {
            int count = resultSet.getInt("total_count");
            countLabel.setText("Number of users who have taken Vaccine " + vaccineId + ": " + count);
        } else {
            countLabel.setText("No data available for the specified vaccine ID");
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

  }

  private void fetchDataFromDatabase() {
      // Database connection parameters
      try {
          Class.forName("oracle.jdbc.driver.OracleDriver");
      } catch (Exception q) {
          q.printStackTrace();
      }
      // Database query to fetch vaccine_id and name columns from the vaccine table
      String query = "SELECT vaccine_id, name FROM vaccine";

      try {
          // Establish the database connection
          Connection connection = DriverManager.getConnection(
                  "jdbc:oracle:thin:@localhost:1521:xe", "rishi", "1234");

          // Create a statement object to execute the query
          Statement statement = connection.createStatement();

          // Execute the query and retrieve the result set
          ResultSet resultSet = statement.executeQuery(query);

          // Iterate over the result set and add rows to the table model
          while (resultSet.next()) {
              String vaccineId = resultSet.getString("vaccine_id");
              String name = resultSet.getString("name");

              model.addRow(new Object[]{vaccineId, name});
          }

          // Close the database connection
          connection.close();
      } catch (Exception e) {
          e.printStackTrace();
      }
  }


public static void main(String[] args) {
    // Create and show the login page
    SwingUtilities.invokeLater(new Runnable() {
        public void run() {

            AdminPage app = new AdminPage();
            app.setVisible(true);
        }
    });
}
}
