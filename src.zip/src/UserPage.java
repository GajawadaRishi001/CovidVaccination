import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.*;

public class UserPage extends JFrame{
int id;
private JTextField userIdField;
  private JButton submitButton;
private JTextField slotIdField;
private JTextField vaccineIdField;
private Connection connection;
private Connection conn;
private JPanel bookSlotPanel=new JPanel();
private JPanel upadteUserPanel;
private JPanel viewSlotPanel;
private JPanel viewUserPanel;
private JPanel containerPanel;
private JPanel mainPanel;
private JLabel userIdLabelres, vaccineIdLabelres, countLabelres;
private JPanel resultPanel;
private JPanel panel;

   private JLabel userIdLabelSt;
   private JLabel vaccineIdLabelSt;
   private JLabel firstDoseLabelSt;
   private JLabel secondDoseLabelSt;
   private JLabel boosterDoseLabelSt;

   private JTextField userIdFieldSt;
   private JTextField vaccineIdFieldSt;
   private JTextField firstDoseFieldSt;
   private JTextField secondDoseFieldSt;
   private JTextField boosterDoseFieldSt;

public UserPage(int userdetuserid){
id=userdetuserid;
mainPanel = new JPanel();
mainPanel.setBounds(0, 0, 400, 300);
mainPanel.setLayout(null);
add(mainPanel);

JMenuBar menuBar = new JMenuBar();
setJMenuBar(menuBar);
JMenu bookSlotMenu = new JMenu("Book Slot");
menuBar.add(bookSlotMenu);

// Create menu item "Book Slot"
JMenuItem bookSlotItem = new JMenuItem("Book Slot");
bookSlotMenu.add(bookSlotItem);

JMenu updateMenu = new JMenu("Update");
menuBar.add(updateMenu);

JMenuItem updateUserItem = new JMenuItem("Update User");
updateMenu.add(updateUserItem);

JMenu viewSlotMenu = new JMenu("View");
menuBar.add(viewSlotMenu);

JMenuItem viewSlotItem = new JMenuItem("View Slot");
viewSlotMenu.add(viewSlotItem);

JMenu statusMenu = new JMenu("Status");
JMenuItem StatusItem = new JMenuItem("Status");
statusMenu.add(StatusItem);
menuBar.add(statusMenu);

JMenu HomeMenu = new JMenu("SignOut");

JMenuItem HomeItem = new JMenuItem("SignOut");
HomeMenu.add(HomeItem);
menuBar.add(HomeMenu);


viewSlotPanel = new JPanel();
viewSlotPanel.setBounds(0, 0, 400, 300);
viewSlotPanel.setLayout(null);
viewSlotPanel.setVisible(false);
mainPanel.add(viewSlotPanel);

containerPanel = new JPanel();
containerPanel.setBounds(0, 0, 400, 300);
containerPanel.setLayout(new BorderLayout());
containerPanel.setVisible(false);
mainPanel.add(containerPanel);

viewUserPanel = new JPanel();
viewUserPanel.setBounds(0, 0, 400, 300);
viewUserPanel.setLayout(new BorderLayout());
viewUserPanel.setVisible(false);
mainPanel.add(viewUserPanel);

bookSlotPanel.setLayout(null);
bookSlotPanel.setBounds(0, 0, 400, 300);
mainPanel.add(bookSlotPanel);

resultPanel = new JPanel();
resultPanel.setBounds(0, 0, 400, 300);
resultPanel.setLayout(null);
resultPanel.setVisible(false); // Set layout to null
mainPanel.add(resultPanel);

 panel = new JPanel(null);

 userIdLabelSt = new JLabel("User ID:");
        userIdLabelSt.setBounds(10, 10, 80, 25);
        panel.add(userIdLabelSt);

        vaccineIdLabelSt = new JLabel("Vaccine ID:");
        vaccineIdLabelSt.setBounds(10, 40, 80, 25);
        panel.add(vaccineIdLabelSt);

        firstDoseLabelSt = new JLabel("First Dose:");
        firstDoseLabelSt.setBounds(10, 70, 80, 25);
        panel.add(firstDoseLabelSt);

        secondDoseLabelSt = new JLabel("Second Dose:");
        secondDoseLabelSt.setBounds(10, 100, 80, 25);
        panel.add(secondDoseLabelSt);

        boosterDoseLabelSt = new JLabel("Booster Dose:");
        boosterDoseLabelSt.setBounds(10, 130, 80, 25);
        panel.add(boosterDoseLabelSt);

        userIdFieldSt = new JTextField();
        userIdFieldSt.setEditable(false);
        userIdFieldSt.setBounds(100, 10, 200, 25);
        panel.add(userIdFieldSt);

        vaccineIdFieldSt = new JTextField();
        vaccineIdFieldSt.setEditable(false);
        vaccineIdFieldSt.setBounds(100, 40, 200, 25);
        panel.add(vaccineIdFieldSt);

        firstDoseFieldSt = new JTextField();
        firstDoseFieldSt.setEditable(false);
        firstDoseFieldSt.setBounds(100, 70, 200, 25);
        panel.add(firstDoseFieldSt);

        secondDoseFieldSt = new JTextField();
        secondDoseFieldSt.setEditable(false);
        secondDoseFieldSt.setBounds(100, 100, 200, 25);
        panel.add(secondDoseFieldSt);

        boosterDoseFieldSt = new JTextField();
        boosterDoseFieldSt.setEditable(false);
        boosterDoseFieldSt.setBounds(100, 130, 200, 25);
        panel.add(boosterDoseFieldSt);

        panel.setBounds(0, 0, 400, 300);
        panel.setLayout(null);
        panel.setVisible(false);
        submitButton = new JButton("View Status");
      submitButton.setBounds(130, 160, 80, 25);
      submitButton.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
              fetchUserDetails();
          }
      });
      panel.add(submitButton);
        mainPanel.add(panel);


vaccineIdLabelres = new JLabel("Vaccine ID:");
countLabelres = new JLabel("Count:");
vaccineIdLabelres.setBounds(10, 10, 80, 25);
countLabelres.setBounds(10, 50, 80, 25);
resultPanel.add(vaccineIdLabelres);
resultPanel.add(countLabelres);



// Create user ID field
/*JLabel userIdLabel = new JLabel("User ID:");
userIdLabel.setBounds(10, 10, 80, 25);
userIdField = new JTextField(10);
userIdField.setBounds(100, 10, 200, 25);
bookSlotPanel.add(userIdLabel);
bookSlotPanel.add(userIdField);*/

// Create slot ID field
JLabel slotIdLabel = new JLabel("Slot ID:");
slotIdLabel.setBounds(10, 40, 80, 25);
slotIdField = new JTextField(10);
slotIdField.setBounds(100, 40, 200, 25);
bookSlotPanel.add(slotIdLabel);
bookSlotPanel.add(slotIdField);

// Create vaccine ID field
JLabel vaccineIdLabel = new JLabel("Vaccine ID:");
vaccineIdLabel.setBounds(10, 70, 80, 25);
vaccineIdField = new JTextField(10);
vaccineIdField.setBounds(100, 70, 200, 25);
bookSlotPanel.add(vaccineIdLabel);
bookSlotPanel.add(vaccineIdField);

// Create submit button
JButton submitBookButton = new JButton("Submit Booking");
submitBookButton.setBounds(150, 100, 80, 25);
bookSlotPanel.add(submitBookButton);

HomeItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      setVisible(false);
      new LoginPagen();
    }
});


bookSlotItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {

        bookSlotPanel.setVisible(true);
        upadteUserPanel.setVisible(false);
        containerPanel.setVisible(false);
        viewUserPanel.setVisible(false);
        resultPanel.setVisible(false);
        panel.setVisible(false);
    }
});

submitBookButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {

        String slotId = slotIdField.getText();
        String vaccineId = vaccineIdField.getText();

        try {
          try{
          Class.forName("oracle.jdbc.driver.OracleDriver");
        }
        catch(Exception q){
          q.printStackTrace();
        }
          connection=DriverManager.getConnection(
            "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");

            // Insert values into booked table
            String insertQuery = "INSERT INTO booked (user_id, slot_id, vaccine_id) VALUES (?, ?, ?)";
            PreparedStatement insertStatement = connection.prepareStatement(insertQuery);
            insertStatement.setInt(1, userdetuserid );
            insertStatement.setString(2, slotId);
            insertStatement.setString(3, vaccineId);
            insertStatement.executeUpdate();
              connection.commit();
            insertStatement.close();

            // Update available table
            String updateQuery = "UPDATE available SET capacity = capacity - 1 WHERE slot_id = ? AND vaccine_id = ?";
            setVisible(false);
            setVisible(true);
            PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
            updateStatement.setString(1, slotId);
            updateStatement.setString(2, vaccineId);
            updateStatement.executeUpdate();
            connection.commit();
            updateStatement.close();

            // Show a message dialog to indicate successful booking
            //connection.commit();
            connection.close();
            JOptionPane.showMessageDialog(UserPage.this,
                    "Booking successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
            updatedet(0);


        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(UserPage.this,
                    "Error occurred during booking.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
});
upadteUserPanel = new JPanel();
upadteUserPanel.setBounds(0, 0, 400, 300);
upadteUserPanel.setLayout(null);
upadteUserPanel.setVisible(false);
mainPanel.add(upadteUserPanel);




JLabel lblUpdateUserName = new JLabel("User Name:");
lblUpdateUserName.setBounds(50, 80, 100, 25);
upadteUserPanel.add(lblUpdateUserName);

JTextField txtUpdateUserName = new JTextField();
txtUpdateUserName.setBounds(150, 80, 200, 25);
upadteUserPanel.add(txtUpdateUserName);

JLabel lblUpdateAge = new JLabel("Age");
lblUpdateAge.setBounds(50, 110, 100, 25);
upadteUserPanel.add(lblUpdateAge);

JTextField txtUpdateAge = new JTextField();
txtUpdateAge.setBounds(150, 110, 200, 25);
upadteUserPanel.add(txtUpdateAge);

JButton btnUpdateUser = new JButton("Update");
btnUpdateUser.setBounds(150, 160, 100, 30);


btnUpdateUser.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle user update

        String userName = txtUpdateUserName.getText();
        int age = Integer.parseInt(txtUpdateAge.getText());
        // Show user update form
        updateUser(userdetuserid,userName,age);

        // Reset the text field

        txtUpdateUserName.setText("");
        txtUpdateAge.setText("");
    }
});
upadteUserPanel.add(btnUpdateUser);

updateUserItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        upadteUserPanel.setVisible(true);
        bookSlotPanel.setVisible(false);
        containerPanel.setVisible(false);
        viewUserPanel.setVisible(false);
        resultPanel.setVisible(false);
        panel.setVisible(false);


    }
});

StatusItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        upadteUserPanel.setVisible(false);
        bookSlotPanel.setVisible(false);
        containerPanel.setVisible(false);
        viewUserPanel.setVisible(false);
        resultPanel.setVisible(false);
        panel.setVisible(true);

    }
});
viewSlotItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      /*try {
      try{
      Class.forName("oracle.jdbc.driver.OracleDriver");
    }
    catch(Exception q){
      q.printStackTrace();
    }
    connection=DriverManager.getConnection(
      "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");
      Statement statement = connection.createStatement();

            // Execute the query
            String query = "SELECT s.slot_id, v.vaccine_id, v.name,a.capacity FROM slot s JOIN available a ON s.slot_id = a.slot_id JOIN vaccine v ON a.vaccine_id = v.vaccine_id";
            ResultSet resultSet = statement.executeQuery(query);

            // Create a 2D array to store the data
            Object[][] data = new Object[100][4]; // Assuming there are 100 rows in the Slot table

            // Populate the data array with the query results
            int row = 0;
            while (resultSet.next()) {
                int id = resultSet.getInt("slot_id");
                int vid = resultSet.getInt("vaccine_id");
                String name = resultSet.getString("name");
                int capacity = resultSet.getInt("capacity");

                data[row][0] = id;
                data[row][1] = vid;
                data[row][2] = name;
                data[row][3] = capacity;
                row++;
            }

            // Define the column names
            String[] columnNames = {"ID", "Vid", "Name", "Capacity"};

            // Create a JTable with the data and column names
            JTable table = new JTable(data, columnNames);

            // Create a JScrollPane to add scroll functionality to the table
            JScrollPane scrollPane = new JScrollPane(table);

            // Create a view panel to hold additional components
            JPanel viewPanel = new JPanel();
            // Add components to the view panel
            viewPanel.add(new JLabel("View Panel Component"));

            // Create a container panel to hold the table and the view panel
            //JPanel containerPanel = new JPanel(new BorderLayout());
            containerPanel.add(scrollPane, BorderLayout.CENTER);
            containerPanel.add(viewPanel, BorderLayout.SOUTH);
          //  mainPanel.add(containerPanel);
        containerPanel.setVisible(true);
        bookSlotPanel.setVisible(false);
        upadteUserPanel.setVisible(false);
        viewUserPanel.setVisible(false);
        resultPanel.setVisible(false);
    }
    catch(Exception q){
      q.printStackTrace();
    }*/
    updatedet(1);

}});


/*viewUserItem.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      try {
      try{
      Class.forName("oracle.jdbc.driver.OracleDriver");
    }
    catch(Exception q){
      q.printStackTrace();
    }
    connection=DriverManager.getConnection(
      "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");
            //Statement preparedStatement = connection.preparedStatement();
            Statement statement = connection.createStatement();

            // Execute query to fetch user dose status based on user ID
            int uri=737042;
            String query = "SELECT vaccine_id, count FROM userdosestatus WHERE user_id = "+userdetuserid ;
            ResultSet resultSet = statement.executeQuery(query);


            // Create a 2D array to store the data
            if (resultSet.next()) {
                // Retrieve data from the result set
                String vaccineIdres = resultSet.getString("vaccine_id");
                int countres = resultSet.getInt("count");

                // Update the labels in the result panel
                vaccineIdLabelres.setText("Vaccine ID: " + vaccineIdres);
                countLabelres.setText("Count: " + countres);
            } else {
                // User dose status not found
                JOptionPane.showMessageDialog(UserPage.this, "User dose status not found!");
            }
            connection.close();
            resultPanel.setVisible(true);
          containerPanel.setVisible(false);
          bookSlotPanel.setVisible(false);
          upadteUserPanel.setVisible(false);
            }
            catch(Exception q){
              q.printStackTrace();
            }

    }


});*/
setSize(500, 500);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setVisible(true);
setLayout(null);
}
private void updatedet(int x)
{
  try {
  try{
  Class.forName("oracle.jdbc.driver.OracleDriver");
}
catch(Exception q){
  q.printStackTrace();
}
connection=DriverManager.getConnection(
  "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");
  Statement statement = connection.createStatement();

        // Execute the query
        String query = "SELECT s.slot_id, v.vaccine_id, v.name,a.capacity FROM slot s JOIN available a ON s.slot_id = a.slot_id JOIN vaccine v ON a.vaccine_id = v.vaccine_id";
        ResultSet resultSet = statement.executeQuery(query);

        // Create a 2D array to store the data
        Object[][] data = new Object[100][4]; // Assuming there are 100 rows in the Slot table

        // Populate the data array with the query results
        int row = 0;
        while (resultSet.next()) {
            int id = resultSet.getInt("slot_id");
            int vid = resultSet.getInt("vaccine_id");
            String name = resultSet.getString("name");
            int capacity = resultSet.getInt("capacity");

            data[row][0] = id;
            data[row][1] = vid;
            data[row][2] = name;
            data[row][3] = capacity;
            row++;
        }

        // Define the column names
        String[] columnNames = {"ID", "Vid", "Name", "Capacity"};

        // Create a JTable with the data and column names
        JTable table = new JTable(data, columnNames);

        // Create a JScrollPane to add scroll functionality to the table
        JScrollPane scrollPane = new JScrollPane(table);

        // Create a view panel to hold additional components
        JPanel viewPanel = new JPanel();
        // Add components to the view panel
        viewPanel.add(new JLabel("View Panel Component"));

        // Create a container panel to hold the table and the view panel
        //JPanel containerPanel = new JPanel(new BorderLayout());
        containerPanel.add(scrollPane, BorderLayout.CENTER);
        containerPanel.add(viewPanel, BorderLayout.SOUTH);
      //  mainPanel.add(containerPanel);
      connection.close();

    containerPanel.setVisible(true);


    bookSlotPanel.setVisible(false);
    upadteUserPanel.setVisible(false);
    viewUserPanel.setVisible(false);
    resultPanel.setVisible(false);
}
catch(Exception q){
  q.printStackTrace();
}
}
private void updateUser(int id,String userName, int age) {
    // Add code to show the form to update user details
    // You can use the same approach as the insertUser method to create the form and update the user record in the database
    try {
      try{
      Class.forName("oracle.jdbc.driver.OracleDriver");
    }
    catch(Exception q){
      q.printStackTrace();
    }
    conn=DriverManager.getConnection(
      "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");

        // Prepare SQL statement
        String query = "UPDATE user_det SET user_name = ?, age = ? WHERE user_id = ?";
        PreparedStatement preparedStatement = conn.prepareStatement(query);


        // Set parameter values
        preparedStatement.setString(1, userName);
        preparedStatement.setInt(2, age);
        preparedStatement.setInt(3, id);

        // Execute the query
        int rowsAffected = preparedStatement.executeUpdate();
          //connection.commit();

        // Close the statement and connection
        preparedStatement.close();
        conn.close();

        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(null, "User updated successfully!");
        } else {
            JOptionPane.showMessageDialog(null, "User with the given ID not found.");
        }

    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error: Failed to update User.");
    }
}

private void fetchUserDetails() {
    Connection connection = null;
    Statement statement = null;
    ResultSet resultSet = null;
try{
    try{
    Class.forName("oracle.jdbc.driver.OracleDriver");
  }
  catch(Exception q){
    q.printStackTrace();
  }
  connection=DriverManager.getConnection(
    "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");
        statement = connection.createStatement();
        resultSet = statement.executeQuery("SELECT * FROM userdosestatus WHERE user_id = "+id) ;

        if (resultSet.next()) {
            int userId = resultSet.getInt("user_id");
            int vaccineId = resultSet.getInt("vaccine_id");
            int firstDose = resultSet.getInt("firstdose");
            int secondDose = resultSet.getInt("seconddose");
            int boosterDose = resultSet.getInt("boosterdose");

            userIdFieldSt.setText(String.valueOf(userId));
            vaccineIdFieldSt.setText(String.valueOf(vaccineId));
            firstDoseFieldSt.setText((firstDose == 1) ? "Taken" : "Not Taken");
            secondDoseFieldSt.setText((secondDose == 1) ? "Taken" : "Not Taken");
            boosterDoseFieldSt.setText((boosterDose == 1) ? "Taken" : "Not Taken");
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}
public static void main(String[] args) {
    // Create and show the login page
    SwingUtilities.invokeLater(new Runnable() {
        public void run() {

            UserPage app = new UserPage(1);
            app.setVisible(true);
        }
    });
}
}
