import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;



public class LoginPagen {
    private JFrame frame;
    private JPanel mainPanel;
    private JPanel loginPanel;
    private JPanel loginPaneln;
    private JPanel signupPanel;
    private Connection conn;



    public LoginPagen() {
        // Create the main frame
        frame = new JFrame("Login Page");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create the main panel
        mainPanel = new JPanel(null);

        // Create the login button
        JButton btnLogin = new JButton("Login");
        btnLogin.setBounds(50, 50, 100, 30);

        // Create the signup button
        JButton btnSignup = new JButton("Sign Up");
        btnSignup.setBounds(250, 50, 100, 30);



        // Add the buttons to the main panel
        loginPaneln = new JPanel(null);
        loginPaneln.add(btnLogin);
        loginPaneln.add(btnSignup);
        loginPaneln.setBounds(0, 0, 400, 300);

        // Create the login panel
        loginPanel = new JPanel(null);
        loginPanel.setBounds(0, 0, 400, 300);

        // Create components for the login panel
        JLabel lblUserId = new JLabel("User ID:");
        lblUserId.setBounds(50, 50, 100, 30);
        JTextField txtUserId = new JTextField();
        txtUserId.setBounds(160, 50, 150, 30);
        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setBounds(50, 90, 100, 30);
        JPasswordField txtPassword = new JPasswordField();
        txtPassword.setBounds(160, 90, 150, 30);
        JButton btnLoginPanelLogin = new JButton("Login");
        btnLoginPanelLogin.setBounds(160, 130, 100, 30);

        // Add components to the login panel
        loginPanel.add(lblUserId);
        loginPanel.add(txtUserId);
        loginPanel.add(lblPassword);
        loginPanel.add(txtPassword);
        loginPanel.add(btnLoginPanelLogin);
        // Add action listener for the login button in the login panel
        btnLoginPanelLogin.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
              String userId = txtUserId.getText();
              int useri=Integer.parseInt(userId);
              String password = new String(txtPassword.getPassword());

              // Check if the provided password matches the corresponding user ID in the login table
              if (checkLoginCredentials(userId, password)) {
            // Password matches, perform login logic here

              JOptionPane.showMessageDialog(frame, "Login successful!");
              frame.setVisible(false);
              new UserPage(useri);
              } else {
            // Password doesn't match, show error message
              JOptionPane.showMessageDialog(frame, "Invalid credentials. Please try again.");
            }
          }
        });

        // Create the signup panel
        signupPanel = new JPanel(null);
        signupPanel.setBounds(0, 0, 400, 300);

        // Create components for the signup panel
        JLabel lblNewUserId = new JLabel("New User ID:");
        lblNewUserId.setBounds(50, 50, 100, 30);
        JTextField txtNewUserId = new JTextField();
        txtNewUserId.setBounds(160, 50, 150, 30);
        JLabel lblNewPassword = new JLabel("New Password:");
        lblNewPassword.setBounds(50, 90, 100, 30);
        JPasswordField txtNewPassword = new JPasswordField();
        txtNewPassword.setBounds(160, 90, 150, 30);
        JLabel lblName = new JLabel("Name:");
        lblName.setBounds(50, 130, 100, 30);
        JTextField txtName = new JTextField();
        txtName.setBounds(160, 130, 150, 30);
        JLabel lblAge = new JLabel("Age:");
        lblAge.setBounds(50, 170, 100, 30);
        JTextField txtAge = new JTextField();
        txtAge.setBounds(160, 170, 150, 30);
        JButton btnSignupPanelSignup = new JButton("Sign Up");
        btnSignupPanelSignup.setBounds(160, 210, 100, 30);

        // Add action listener for the signup button
        btnSignupPanelSignup.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newUserId = txtNewUserId.getText();
                String newPassword = new String(txtNewPassword.getPassword());
                String name = txtName.getText();
                int age = Integer.parseInt(txtAge.getText());

                // Insert new user credentials into login table
                insertUserCredentials(newUserId, newPassword);

                // Insert new user details into user_det table
                insertUserDetails(newUserId, name, age);
                JOptionPane.showMessageDialog(frame, "Signup sucessful");
            }
        });

        // Add components to the signup panel
        signupPanel.add(lblNewUserId);
        signupPanel.add(txtNewUserId);
        signupPanel.add(lblNewPassword);
        signupPanel.add(txtNewPassword);
        signupPanel.add(lblName);
        signupPanel.add(txtName);
        signupPanel.add(lblAge);
        signupPanel.add(txtAge);
        signupPanel.add(btnSignupPanelSignup);

        // Create the menu bar
        JMenuBar menuBar = new JMenuBar();
        frame.setJMenuBar(menuBar);

        // Create the login menu
        JMenu loginMenu = new JMenu("Login");
        menuBar.add(loginMenu);

        // Create the user login menu item
        JMenuItem userLoginMenuItem = new JMenuItem("User Login");
        loginMenu.add(userLoginMenuItem);

        // Create the admin login menu item (placeholder)
        JMenuItem adminLoginMenuItem = new JMenuItem("Admin Login");
        loginMenu.add(adminLoginMenuItem);

        // Create the signup menu
        JMenu signupMenu = new JMenu("Signup");
        menuBar.add(signupMenu);

        // Create the user signup menu item
        JMenuItem userSignupMenuItem = new JMenuItem("User Signup");
        signupMenu.add(userSignupMenuItem);

        // Create the home menu item
        JMenuItem homeMenuItem = new JMenuItem("Home");
        menuBar.add(homeMenuItem);

        // Add action listeners for the menu items
        userLoginMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showLoginPanel();
            }
        });

        userSignupMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showSignupPanel();
            }
        });

        homeMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /*showMainPanel();*/
                new Updating();
                //new AdminPage();
            }
        });
        adminLoginMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /*showMainPanel();*/
                new AdminPage();
                //new AdminPage();
            }
        });

        // Show the main panel by default
        frame.add(mainPanel);

        // Display the frame
        frame.setVisible(true);
    }

    private void showMainPanel() {
        // Show the main panel

        mainPanel.removeAll();
        mainPanel.add(loginPaneln);
        mainPanel.repaint();
        mainPanel.revalidate();
    }

    private void showLoginPanel() {
        // Show the login panel
        mainPanel.removeAll();
        mainPanel.add(loginPanel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }

    private void showSignupPanel() {
        // Show the signup panel
        mainPanel.removeAll();
        mainPanel.add(signupPanel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }

    private void insertUserCredentials(String userId, String password) {
        try {
            // Establish a database connection
            try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
          }
          catch(Exception q){
            q.printStackTrace();
          }
          conn=DriverManager.getConnection(
            "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");

            // Prepare the SQL statement
            String sql = "INSERT INTO login (user_id, password) VALUES (?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, userId);
            statement.setString(2, password);

            // Execute the statement
            statement.executeUpdate();

            // Close the database connection
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void insertUserDetails(String userId, String name, int age) {
        try {
            // Establish a database connection
            try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
          }
          catch(Exception q){
            q.printStackTrace();
          }
          conn=DriverManager.getConnection(
            "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");

            // Prepare the SQL statement
            String sql = "INSERT INTO user_det (user_id, user_name, age) VALUES (?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, userId);
            statement.setString(2, name);
            statement.setInt(3, age);

            // Execute the statement
            statement.executeUpdate();

            // Close the database connection
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private boolean checkLoginCredentials(String userId, String password) {
      try {
    // Establish a database connection
    try{
    Class.forName("oracle.jdbc.driver.OracleDriver");
  }
  catch(Exception q){
    q.printStackTrace();
  }
  conn=DriverManager.getConnection(
    "jdbc:oracle:thin:@localhost:1521:xe","rishi","1234");

    // Prepare the SQL statement to retrieve the stored password for the given user ID
    String sql = "SELECT password FROM login WHERE user_id = ?";
    PreparedStatement statement = conn.prepareStatement(sql);
    statement.setString(1, userId);

    // Execute the statement and retrieve the result set
    ResultSet resultSet = statement.executeQuery();

    // Check if a row with the given user ID exists in the login table
    if (resultSet.next()) {
        // Retrieve the stored password for the given user ID
        String storedPassword = resultSet.getString("password");

        // Compare the stored password with the entered password
        if (password.equals(storedPassword)) {
            // Passwords match, return true
            conn.close();
            return true;
        }
    }

    // Close the result set, statement, and connection
    resultSet.close();
    statement.close();
    conn.close();
} catch (SQLException e) {
    e.printStackTrace();
}

// Passwords don't match or an error occurred, return false
return false;
}

    public static void main(String[] args) {
        // Create and show the login page
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new LoginPagen();
            }
        });
    }
}
